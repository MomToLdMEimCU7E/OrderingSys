package com.example.demo.Vo;

import lombok.Data;

@Data
public class UserInfoVo {
    private Integer uid;
    private String username;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
